package com.example.BaiTapCuoiKhoa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaiTapCuoiKhoaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaiTapCuoiKhoaApplication.class, args);
	}

}
